-- --------------------------------------------------------
-- Host:                         localhost
-- Versión del servidor:         5.7.24 - MySQL Community Server (GPL)
-- SO del servidor:              Win64
-- HeidiSQL Versión:             10.2.0.5599
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Volcando estructura de base de datos para tienda
DROP DATABASE IF EXISTS `tienda`;
CREATE DATABASE IF NOT EXISTS `tienda` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `tienda`;

-- Volcando estructura para tabla tienda.agendamientos
DROP TABLE IF EXISTS `agendamientos`;
CREATE TABLE IF NOT EXISTS `agendamientos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_emprendedor` int(11) NOT NULL,
  `nombre` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(320) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefono` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `observaciones` varchar(320) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dia` varchar(12) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hora` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha_registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_agendamientos_emprendedor` (`id_emprendedor`),
  CONSTRAINT `fk_agendamientos_emprendedor` FOREIGN KEY (`id_emprendedor`) REFERENCES `emprendedores` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=236 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla tienda.categorias
DROP TABLE IF EXISTS `categorias`;
CREATE TABLE IF NOT EXISTS `categorias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` varchar(156) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `orden` int(11) NOT NULL,
  `fecha_creado` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla tienda.ciudades
DROP TABLE IF EXISTS `ciudades`;
CREATE TABLE IF NOT EXISTS `ciudades` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_departamento` int(11) DEFAULT NULL,
  `id_pais` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `slug` varchar(100) NOT NULL,
  `abr` varchar(3) NOT NULL,
  `bandera` varchar(50) NOT NULL DEFAULT 'sin-bandera.png',
  `orden` int(11) NOT NULL,
  `estado` enum('1','0') NOT NULL DEFAULT '1',
  `fecha_creado` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `id_departamento` (`id_departamento`),
  KEY `id_pais` (`id_pais`),
  CONSTRAINT `fk_ciudad_departamento` FOREIGN KEY (`id_departamento`) REFERENCES `departamentos` (`id`),
  CONSTRAINT `fk_ciudad_pais` FOREIGN KEY (`id_pais`) REFERENCES `paises` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2417 DEFAULT CHARSET=utf8mb4;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla tienda.clientes
DROP TABLE IF EXISTS `clientes`;
CREATE TABLE IF NOT EXISTS `clientes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cookie` varchar(10) NOT NULL,
  `ISO` char(2) DEFAULT NULL,
  `nombres` varchar(500) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `email` varchar(320) DEFAULT NULL,
  `fecha_registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fecha_creacion` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=44719 DEFAULT CHARSET=utf8mb4 COMMENT='Almacena los clientes que van a comprar a través de la tienda';

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla tienda.compras
DROP TABLE IF EXISTS `compras`;
CREATE TABLE IF NOT EXISTS `compras` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_cliente` int(11) NOT NULL,
  `id_pais` int(11) NOT NULL,
  `id_ciudad` int(11) DEFAULT NULL,
  `total` float DEFAULT NULL,
  `estado` enum('2','1','0') NOT NULL DEFAULT '1',
  `fecha_creacion` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `fecha_compra` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_compra_cliente` (`id_cliente`),
  KEY `id_pais` (`id_pais`),
  KEY `id_ciudad` (`id_ciudad`),
  CONSTRAINT `fk_compra_ciudad` FOREIGN KEY (`id_ciudad`) REFERENCES `ciudades` (`id`),
  CONSTRAINT `fk_compra_cliente` FOREIGN KEY (`id_cliente`) REFERENCES `clientes` (`id`),
  CONSTRAINT `fk_compra_pais` FOREIGN KEY (`id_pais`) REFERENCES `paises` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=854 DEFAULT CHARSET=utf8mb4 COMMENT='Carro de compra';

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla tienda.compras_detalle
DROP TABLE IF EXISTS `compras_detalle`;
CREATE TABLE IF NOT EXISTS `compras_detalle` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_compra` int(11) NOT NULL,
  `id_cliente` int(11) NOT NULL,
  `id_emprendedor` int(11) NOT NULL,
  `id_producto` int(11) NOT NULL,
  `id_pais` int(11) NOT NULL,
  `id_ciudad` int(11) DEFAULT NULL,
  `cantidad` int(11) NOT NULL,
  `valor_unitario` float NOT NULL,
  `subtotal` float DEFAULT NULL,
  `estado` enum('2','1','0') NOT NULL DEFAULT '1',
  `fecha_creacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fecha_modificacion` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_detalle_compra` (`id_compra`),
  KEY `fk_detalle_emprendedor` (`id_emprendedor`),
  KEY `fk_detalle_producto` (`id_producto`),
  KEY `fk_detalle_cliente` (`id_cliente`),
  KEY `id_pais` (`id_pais`),
  KEY `id_ciudad` (`id_ciudad`),
  CONSTRAINT `fk_detalle_ciudad` FOREIGN KEY (`id_ciudad`) REFERENCES `ciudades` (`id`),
  CONSTRAINT `fk_detalle_cliente` FOREIGN KEY (`id_cliente`) REFERENCES `clientes` (`id`),
  CONSTRAINT `fk_detalle_compra` FOREIGN KEY (`id_compra`) REFERENCES `compras` (`id`),
  CONSTRAINT `fk_detalle_emprendedor` FOREIGN KEY (`id_emprendedor`) REFERENCES `emprendedores` (`id`),
  CONSTRAINT `fk_detalle_pais` FOREIGN KEY (`id_pais`) REFERENCES `paises` (`id`),
  CONSTRAINT `fk_detalle_producto` FOREIGN KEY (`id_producto`) REFERENCES `productos` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1054 DEFAULT CHARSET=utf8mb4 COMMENT='Detalle de los productos agregados al carrito';

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla tienda.departamentos
DROP TABLE IF EXISTS `departamentos`;
CREATE TABLE IF NOT EXISTS `departamentos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_pais` int(11) NOT NULL,
  `nombre` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `codigo` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_pais` (`id_pais`),
  CONSTRAINT `fk_departamento_pais` FOREIGN KEY (`id_pais`) REFERENCES `paises` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla tienda.direcciones
DROP TABLE IF EXISTS `direcciones`;
CREATE TABLE IF NOT EXISTS `direcciones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_cliente` int(11) NOT NULL,
  `id_pais` int(11) NOT NULL,
  `id_ciudad` int(11) DEFAULT NULL,
  `direccion` varchar(500) NOT NULL,
  `barrio` varchar(500) NOT NULL,
  `observaciones` varchar(500) DEFAULT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `FK_direcciones_clientes` (`id_cliente`),
  KEY `id_pais` (`id_pais`),
  KEY `id_ciudad` (`id_ciudad`),
  CONSTRAINT `FK_direcciones_clientes` FOREIGN KEY (`id_cliente`) REFERENCES `clientes` (`id`),
  CONSTRAINT `fk_direcciones_ciudad` FOREIGN KEY (`id_ciudad`) REFERENCES `ciudades` (`id`),
  CONSTRAINT `fk_direcciones_pais` FOREIGN KEY (`id_pais`) REFERENCES `paises` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=180 DEFAULT CHARSET=utf8mb4 COMMENT='Direcciones de entrega de los pedidos';

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla tienda.emprendedores
DROP TABLE IF EXISTS `emprendedores`;
CREATE TABLE IF NOT EXISTS `emprendedores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_ciudad` int(11) NOT NULL,
  `id_pais` int(11) NOT NULL,
  `nombre` varchar(500) NOT NULL,
  `descripcion` varchar(155) DEFAULT NULL,
  `emprendimiento` varchar(200) NOT NULL,
  `logo` varchar(200) DEFAULT 'default.jpg',
  `slug` varchar(200) DEFAULT NULL,
  `telefono` varchar(20) NOT NULL,
  `whatsapp` bit(1) NOT NULL DEFAULT b'0',
  `codigo_activacion` int(11) DEFAULT NULL,
  `email` varchar(320) DEFAULT NULL,
  `hora_inicio` time DEFAULT NULL,
  `hora_cierre` time DEFAULT NULL,
  `fecha_registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `fecha_modificacion` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_ciudad` (`id_ciudad`),
  KEY `id_pais` (`id_pais`),
  CONSTRAINT `fk_emprendedor_ciudad` FOREIGN KEY (`id_ciudad`) REFERENCES `ciudades` (`id`),
  CONSTRAINT `fk_emprendedor_pais` FOREIGN KEY (`id_pais`) REFERENCES `paises` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1372 DEFAULT CHARSET=utf8mb4;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla tienda.emprendedores_ciudad
DROP TABLE IF EXISTS `emprendedores_ciudad`;
CREATE TABLE IF NOT EXISTS `emprendedores_ciudad` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_emprendedor` int(11) NOT NULL,
  `id_ciudad` int(11) NOT NULL,
  `fecha_creado` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_emprendedores_emprendedor` (`id_emprendedor`),
  KEY `fk_emprendedores_ciudad` (`id_ciudad`),
  CONSTRAINT `fk_emprendedores_ciudad` FOREIGN KEY (`id_ciudad`) REFERENCES `ciudades` (`id`),
  CONSTRAINT `fk_emprendedores_emprendedor` FOREIGN KEY (`id_emprendedor`) REFERENCES `emprendedores` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4296 DEFAULT CHARSET=utf8mb4;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para vista tienda.emprendedores_feria
DROP VIEW IF EXISTS `emprendedores_feria`;
-- Creando tabla temporal para superar errores de dependencia de VIEW
CREATE TABLE `emprendedores_feria` (
	`nombre` VARCHAR(500) NOT NULL COLLATE 'utf8mb4_general_ci',
	`emprendimiento` VARCHAR(200) NOT NULL COLLATE 'utf8mb4_general_ci',
	`ciudad` VARCHAR(50) NOT NULL COLLATE 'utf8mb4_general_ci',
	`telefono` VARCHAR(20) NOT NULL COLLATE 'utf8mb4_general_ci',
	`email` VARCHAR(320) NULL COLLATE 'utf8mb4_general_ci',
	`actividades` VARCHAR(100) NOT NULL COLLATE 'utf8mb4_unicode_ci',
	`permisos` VARCHAR(500) NOT NULL COLLATE 'utf8mb4_unicode_ci',
	`productos` VARCHAR(500) NOT NULL COLLATE 'utf8mb4_unicode_ci',
	`tipo_cliente` VARCHAR(500) NOT NULL COLLATE 'utf8mb4_unicode_ci',
	`mentorias` VARCHAR(1000) NOT NULL COLLATE 'utf8mb4_unicode_ci',
	`dudas` VARCHAR(500) NOT NULL COLLATE 'utf8mb4_unicode_ci'
) ENGINE=MyISAM;

-- Volcando estructura para tabla tienda.eventos
DROP TABLE IF EXISTS `eventos`;
CREATE TABLE IF NOT EXISTS `eventos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `slug` varchar(100) DEFAULT NULL,
  `descripcion` varchar(500) NOT NULL,
  `capacidad` int(11) NOT NULL DEFAULT '0',
  `fecha_evento` datetime DEFAULT NULL,
  `fecha_registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla tienda.feria_pereira
DROP TABLE IF EXISTS `feria_pereira`;
CREATE TABLE IF NOT EXISTS `feria_pereira` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_emprendedor` int(11) NOT NULL,
  `actividades` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `permisos` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `productos` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo_cliente` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mentorias` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dudas` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `seleccionado` bit(1) NOT NULL DEFAULT b'0',
  `fecha_registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_feria_emprendedor` (`id_emprendedor`),
  CONSTRAINT `fk_feria_emprendedor` FOREIGN KEY (`id_emprendedor`) REFERENCES `emprendedores` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=199 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla tienda.paises
DROP TABLE IF EXISTS `paises`;
CREATE TABLE IF NOT EXISTS `paises` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `bandera` varchar(50) NOT NULL,
  `ISO` char(2) NOT NULL,
  `ISO2` char(3) DEFAULT NULL,
  `divisa` varchar(100) NOT NULL,
  `codigo` char(3) NOT NULL,
  `simbolo` char(3) NOT NULL,
  `prefijo` char(3) NOT NULL,
  `telefono` tinyint(4) NOT NULL,
  `valor_minimo` float NOT NULL,
  `precio_minimo` float NOT NULL,
  `step` float NOT NULL,
  `decimales` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf32;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla tienda.productos
DROP TABLE IF EXISTS `productos`;
CREATE TABLE IF NOT EXISTS `productos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_emprendedor` int(11) NOT NULL,
  `id_categoria` int(11) DEFAULT NULL,
  `nombre` varchar(50) NOT NULL,
  `imagen` varchar(50) NOT NULL DEFAULT 'default.jpg',
  `descripcion` varchar(500) NOT NULL,
  `precio` float NOT NULL,
  `estado` enum('1','0') NOT NULL DEFAULT '1',
  `fecha_creacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_producto_emprendedor` (`id_emprendedor`),
  KEY `id_categoria` (`id_categoria`),
  CONSTRAINT `fk_producto_categoria` FOREIGN KEY (`id_categoria`) REFERENCES `categorias` (`id`),
  CONSTRAINT `fk_producto_emprendedor` FOREIGN KEY (`id_emprendedor`) REFERENCES `emprendedores` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2875 DEFAULT CHARSET=utf8mb4 COMMENT='Productos de los emprendedores';

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla tienda.sesiones
DROP TABLE IF EXISTS `sesiones`;
CREATE TABLE IF NOT EXISTS `sesiones` (
  `id` varchar(128) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) unsigned NOT NULL DEFAULT '0',
  `data` blob NOT NULL,
  KEY `ci_sessions_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para vista tienda.emprendedores_feria
DROP VIEW IF EXISTS `emprendedores_feria`;
-- Eliminando tabla temporal y crear estructura final de VIEW
DROP TABLE IF EXISTS `emprendedores_feria`;
CREATE ALGORITHM=UNDEFINED DEFINER=`emprendedores`@`10.%` SQL SECURITY DEFINER VIEW `emprendedores_feria` AS select `e`.`nombre` AS `nombre`,`e`.`emprendimiento` AS `emprendimiento`,`c`.`nombre` AS `ciudad`,`e`.`telefono` AS `telefono`,`e`.`email` AS `email`,`f`.`actividades` AS `actividades`,`f`.`permisos` AS `permisos`,`f`.`productos` AS `productos`,`f`.`tipo_cliente` AS `tipo_cliente`,`f`.`mentorias` AS `mentorias`,`f`.`dudas` AS `dudas` from ((`emprendedores` `e` join `feria_pereira` `f` on((`e`.`id` = `f`.`id_emprendedor`))) join `ciudades` `c` on((`c`.`id` = `e`.`id_ciudad`))) ;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
